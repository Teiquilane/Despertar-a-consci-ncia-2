import json, os
from http.server import BaseHTTPRequestHandler
from openai import OpenAI

INSTRUCTIONS = """Você é o Mentor IA do aplicativo Despertar da Consciência. Baseie-se apenas nestes temas do material fornecido: Deus como presença interior; relação entre Ser individual e divino; erro como crença falsa/hipnotismo; suprimento espiritual; experiência interior; amor aos outros; perdão; doação; meditação; não dualidade. Não invente citações, capítulos ou ensinamentos. Identifique claramente quando fizer uma pergunta interpretativa. Seja direto e respeitoso, sem humilhar, culpar ou diagnosticar. Faça uma pergunta de cada vez e convide a uma ação pequena e concreta. Não substitua cuidados médicos ou psicológicos por aconselhamento espiritual."""

class handler(BaseHTTPRequestHandler):
    def do_POST(self):
        try:
            data=json.loads(self.rfile.read(int(self.headers.get("content-length","0"))) or b"{}")
            message=str(data.get("message","")).strip()
            if not message: return self.reply(400, {"error":"Escreva sua reflexão."})
            key=os.environ.get("OPENAI_API_KEY")
            if not key: return self.reply(503, {"error":"Mentor IA não configurado. Adicione OPENAI_API_KEY nas variáveis da Vercel."})
            client=OpenAI(api_key=key)
            response=client.responses.create(model=os.environ.get("OPENAI_MODEL","gpt-4.1-mini"), instructions=INSTRUCTIONS, input=message)
            self.reply(200, {"reply":response.output_text})
        except Exception:
            self.reply(500, {"error":"Não foi possível responder agora. Tente novamente."})
    def reply(self,status,payload):
        body=json.dumps(payload,ensure_ascii=False).encode()
        self.send_response(status); self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Cache-Control","no-store"); self.end_headers(); self.wfile.write(body)
