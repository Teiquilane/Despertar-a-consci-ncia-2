# Despertar da Consciência

Protótipo inicial para publicação na Vercel.

## Inclui
- Página responsiva com Início, Ensinamentos, Mentor IA e Diário.
- Dez temas organizados a partir do trecho de livro fornecido.
- Endpoint Python `/api/chat` para integrar a API da OpenAI.

## Publicação
1. Envie estes arquivos ao repositório GitHub.
2. Importe o repositório na Vercel.
3. Em Settings > Environment Variables, configure `OPENAI_API_KEY` com sua chave da API da OpenAI.
4. Opcionalmente configure `OPENAI_MODEL` (padrão `gpt-4.1-mini`) e faça redeploy.

## Limitações desta versão
- Diário e progresso não têm banco de dados; não sincronizam entre dispositivos e podem ser perdidos.
- O histórico do Mentor IA não é salvo.
- Antes de abrir ao público, implementar autenticação, banco persistente, limites de uso, monitoramento e política de privacidade.
- O conteúdo reflete os temas do trecho de livro fornecido; não pressupõe acesso à obra integral.
- O app é para estudo espiritual e não substitui cuidados médicos ou psicológicos.
- Nunca coloque a chave da OpenAI no HTML ou no GitHub. Configure-a apenas nas variáveis de ambiente da Vercel.
